class Aurora < Formula
  desc "Launcher for the Aurora Bioscience Dashboard"
  homepage "https://github.com/your-username/aurora"
  # PASTE YOUR RELEASE LINK BELOW
  url "https://github.com/your-username/aurora/releases/download/v1.0.0/genelab-1.0.0.tar.gz"
  sha256 "2c2faffde75e83dc188c7a8db5d035dfda3fcfc4830babcd75e119e0c7547779"
  version "1.0.0"

  depends_on "node"
  depends_on "python@3.12"

  def install
    libexec.install Dir["*"]

    cd "#{libexec}/genelab" do
      system "npm", "install", "--production"
    end

    if OS.mac?
      system "xattr", "-rd", "com.apple.quarantine", "#{libexec}"
    end

    (bin/"aurora").write <<~EOS
      #!/usr/bin/env python3
      import os, subprocess, sys, platform
      def main():
          msg = "There could be an error. If there is, just press OK."
          if platform.system() == "Darwin":
              os.system(f"osascript -e 'display dialog \\\"{msg}\\\" buttons {{\\\"OK\\\"}} default button \\\"OK\\\"'")
          else:
              print(f"INFO: {msg}")
          app_dir = "#{libexec}/genelab"
          try:
              subprocess.run(["npm", "start"], cwd=app_dir)
          except Exception as e:
              print(f"Error launching Aurora: {e}")
              sys.exit(1)
      if __name__ == "__main__":
          main()
    EOS

    chmod 0755, bin/"aurora"
  end
end