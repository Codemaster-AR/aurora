#!/usr/bin/env python3
import os
import subprocess
import sys
import platform

def main():
    # 1. Display the dialog based on OS
    msg = "There could be an error. If there is, just press OK."
    if platform.system() == "Darwin":
        # macOS: Use AppleScript for a native popup
        os.system(f"osascript -e 'display dialog \"{msg}\" buttons {{\"OK\"}} default button \"OK\"'")
    else:
        # Linux / WSL: Print to console
        print(f"INFO: {msg}")

    # 2. Get the current app directory (where package.json is located)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.join(script_dir, "genelab")
    
    # Fallback check if script is already inside the genelab folder
    if not os.path.exists(os.path.join(app_dir, "package.json")):
        app_dir = script_dir

    try:
        # 3. Launch the Electron app using npm start
        subprocess.run(["npm", "start"], cwd=app_dir)
    except Exception as e:
        print(f"Error launching Genelab: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()