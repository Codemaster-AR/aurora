const { app, BrowserWindow } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let proxyProcess; // Declare proxyProcess here

function createWindow() {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            webSecurity: true,
            contextIsolation: true,
            nodeIntegration: false,
            devTools: true // Explicitly enable DevTools
        }
    });

    win.loadFile(path.join(__dirname, 'index.html'));
    win.webContents.openDevTools();
    
}

app.whenReady().then(() => {
    // Start the proxy server
    proxyProcess = spawn('node', [path.join(__dirname, 'proxy.js')]);

    proxyProcess.stdout.on('data', (data) => {
        console.log(`Proxy stdout: ${data}`);
    });

    proxyProcess.stderr.on('data', (data) => {
        console.error(`Proxy stderr: ${data}`);
    });

    proxyProcess.on('close', (code) => {
        console.log(`Proxy process exited with code ${code}`);
    });

    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('will-quit', () => {
    // Kill the proxy process when the Electron app is closing
    if (proxyProcess) {
        proxyProcess.kill();
    }
});
